package org.tedu.cloudnote.dao;

import org.tedu.cloudnote.entity.Emp;

public interface EmpDao {
	public void save(Emp emp);
}
