package test.dao;

public class TestTask {

	public void f1(){
		//TODO �߼�1
		System.out.println("----");
	}
	
	public void f2(){
		//TODO �߼�2
	}
	
}
