package test.dao;

import org.junit.Assert;
import org.junit.Test;

public class TestAssert {
	@Test
	public void test1(){
		
	}
}
