package test.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.tedu.dao.EmpDao;
import org.tedu.entity.Emp;

public class TestEmp {
	@Test//����empDao
	public void test3(){
		String conf = "spring-hibernate.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(conf);
		EmpDao dao = ac.getBean(
			"empDao",EmpDao.class);
		List<Emp> list = dao.findLikeName("%n%");
		for(Emp e:list){
			System.out.println(
				e.getNo()+" "+e.getName());
		}
	}
	
	@Test//����HibernateTemplate
	public void test2(){
		String conf = "spring-hibernate.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(conf);
		HibernateTemplate template = 
		ac.getBean("template",HibernateTemplate.class);
		//ִ������
		Emp emp = new Emp();
		emp.setName("zhangsan");
		emp.setSal(6000.0);
		template.save(emp);
	}
	
	@Test//����SessionFactory�����hbm.xml������ȷ��
	public void test1(){
		String conf = "spring-hibernate.xml";
		ApplicationContext ac = 
		new ClassPathXmlApplicationContext(conf);
		SessionFactory factory = ac.getBean(
		"sessionFactory",SessionFactory.class);
		System.out.println(factory.openSession());
	}
}



