import org.apache.struts2.dispatcher.ng.filter.StrutsPrepareAndExecuteFilter;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.orm.hibernate3.LocalSessionFactoryBean;
import org.springframework.orm.hibernate3.support.OpenSessionInViewFilter;

public class Test {
	//LocalSessionFactoryBean
//	HibernateTemplate
	//StrutsPrepareAndExecuteFilter
	//OpenSessionInViewFilter
//	HibernateTransactionManager
}
