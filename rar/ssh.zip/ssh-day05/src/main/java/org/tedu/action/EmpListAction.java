package org.tedu.action;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.tedu.dao.EmpDao;
import org.tedu.entity.Emp;

@Controller//ɨ��
@Scope("prototype")//�ǵ�������
@Transactional(readOnly=true)
public class EmpListAction {
	//input��
	//output
	private List<Emp> emps;
	@Resource//ע��
	private EmpDao empDao;

	public String execute(){
		emps = empDao.findAll();
		return "success";
	}
	
	public List<Emp> getEmps() {
		return emps;
	}

	public void setEmps(List<Emp> emps) {
		this.emps = emps;
	}
}
