package org.tedu.dao;

import java.util.List;

import org.tedu.entity.Emp;

public interface EmpDao {
	public void save(Emp emp);
	public void delete(Emp emp);
	public void update(Emp emp);
	public Emp findById(int id);
	public List<Emp> findAll();
	public List<Emp> findLikeName(String name);
}
