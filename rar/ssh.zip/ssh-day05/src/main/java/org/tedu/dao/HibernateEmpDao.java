package org.tedu.dao;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.tedu.entity.Emp;

@Repository("empDao")
public class HibernateEmpDao implements EmpDao{
	@Resource
	private HibernateTemplate template;
	//�������OpenSessionInViewFilter��
	//template����ִ����Ϻ�Ͳ���ر�session��
	//����������Filter���Զ��ر�session
	
	public void save(Emp emp) {
		template.save(emp);
	}

	public void delete(Emp emp) {
		template.delete(emp);
	}

	public void update(Emp emp) {
		template.update(emp);
	}

	public Emp findById(int id) {
		Emp emp = (Emp)template.load(
			Emp.class, id);
		return emp;
	}

	public List<Emp> findAll() {
		String hql = "from Emp";
		List<Emp> list = template.find(hql);
		return list;
	}

	public List<Emp> findLikeName(String name) {
		String hql = 
			"from Emp where name like ?";
		Object[] params = {name};
		List<Emp> list = 
			template.find(hql,params);
		return list;
	}

	
	
}
