package org.tedu.action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.tedu.dao.EmpDao;
import org.tedu.entity.Emp;
@Controller
@Scope("prototype")
public class EmpUpdateAction {
	//input
	private int no;
	//output,input
	private Emp emp;
	//injection
	@Resource
	private EmpDao empDao;
	//����updateҳ��,��ʾdb�е�����
	@Transactional(readOnly=true)
	public String show(){
		emp = empDao.findById(no);
		return "success";
	}
	//�ύ��ť����,����db
	@Transactional
	public String update(){
		empDao.update(emp);
		return "success";
	}
	
	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public Emp getEmp() {
		return emp;
	}

	public void setEmp(Emp emp) {
		this.emp = emp;
	}
}
