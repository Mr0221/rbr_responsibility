package cn.lai.netstoss.service;

public interface CostService {

}
