package cn.lai.netstoss.service;

import cn.lai.netstoss.Entity.Admin;

public interface AdminService {
	public Admin findByCode(String code);
}
