package cn.lai.netstoss.dao;
public interface CostDao {
	
}
