package cn.lai.netstoss.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import cn.lai.netstoss.service.CostService;

////@Controller
//public class CostController{
////	@Resource(name="costService")
////	private CostService sercice;
//}
