package cn.lai.netstoss.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import cn.lai.netstoss.Entity.Admin;
import cn.lai.netstoss.service.AdminService;

/**
 *	用注解的方式开发Controller
 * 1 不用实现Controller
 * 2 可以添加多个处理方法
 * 3 处理方法
 *  a.方法名不做要求
 *  b.返回值可以是ModelAndView 
 *  可以是String ， 可以是void
 *  区别如果返回的既有数据， 也有视图名 可以使用ModeAndView 如果只有视图名可以返回String。
 * 4 使用到的注解：
 * @Controller ： 要加在类前面
 *@RequestMapping： 可以加到类前面， 也可以添加到处理方法前面，用来设置请求路径与处理方法的对应关系
 */

@Controller
//@RequestMapping("/demo")
public class HelloController {
	
	@Resource(name="adminService")
	private AdminService service;
	
	@RequestMapping("/testAdmin.do")
	public String testAdmin(HttpServletRequest request){
		Admin a = service.findByCode("caocao");
		request.setAttribute("name", a.getName());
		request.setAttribute("phone", a.getTelephone());
		return "testAdmin";
	}
	public HelloController() {
		
	}
	
	@RequestMapping("/hello.do")
	public ModelAndView toHello(){
		System.out.println("HelloController::toHello()");
		return new ModelAndView("hello");
	}	
}
