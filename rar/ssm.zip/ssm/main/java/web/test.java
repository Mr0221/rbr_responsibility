package web;

public class test {

    public static void main(final String[] args) {
        // TODO Auto-generated method stub
        System.out.print("123");
    }

}
