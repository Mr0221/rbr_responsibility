package com.spring.ssm.control;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.ssm.serverImp.ServerImp;

@Controller
@RequestMapping("/path")
public class Controlor {
    @Resource
    private ServerImp serverImp;

    @RequestMapping("/Subpath")
    @ResponseBody
    public void excute() {
        serverImp.update();
    }
}
