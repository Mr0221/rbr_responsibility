package com.spring.ssm.serverImp;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.spring.ssm.dao.ImybatisDao;
import com.spring.ssm.serverInterface.IServer;

@Service("serverImp")
public class ServerImp implements IServer {
    @Resource
    private ImybatisDao imybatisDao;
    @Override
    public void update() {
        final Map params = new HashMap();
        params.put("name", "name");
        params.put("password","password");
        imybatisDao.update_my(params);
    }

}
