package com.spring.ssm.serverInterface;


public interface IServer {
    public void update();
}
