package com.spring.ssm.dao;

import java.util.Map;

public interface ImybatisDao {
    public int update_my(
            Map<String,Object> params);
}
